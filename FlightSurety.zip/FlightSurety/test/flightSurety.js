
var Test = require('../config/testConfig.js');
var BigNumber = require('bignumber.js');

contract('Flight Surety Tests', async (accounts) => {

  var config;
  before('setup contract', async () => {
    config = await Test.Config(accounts);
    await config.flightSuretyData.authorizeCaller(config.flightSuretyApp.address);
  });

  /****************************************************************************************/
  /* Operations and Settings                                                              */
  /****************************************************************************************/




  it('Owner airline is registered as first airline on deployment', async () => {
    
    // ARRANGE
    let ownerAirline = accounts[0];
    let result = false;

    // ACT
    result = await config.flightSuretyData.isAirline.call(ownerAirline); 

    // ASSERT
    assert.equal(result, true, "Owner is not registered as first airline");

  });

  it(`(multiparty) has correct initial isOperational() value`, async function () {

    // Get operating status
    let status = await config.flightSuretyData.isOperational.call();
    assert.equal(status, true, "Incorrect initial operating status value");

  });

  it(`(multiparty) can block access to setOperatingStatus() for non-Contract Owner account`, async function () {

      // Ensure that access is denied for non-Contract Owner account
      let accessDenied = false;
      try 
      {
          await config.flightSuretyData.setOperatingStatus(false, { from: config.testAddresses[2] });
      }
      catch(e) {
          accessDenied = true;
      }
      assert.equal(accessDenied, true, "Access not restricted to Contract Owner");
            
  });

  it(`(multiparty) can allow access to setOperatingStatus() for Contract Owner account`, async function () {

      // Ensure that access is allowed for Contract Owner account
      let accessDenied = false;
      try 
      {
          await config.flightSuretyData.setOperatingStatus(false);
      }
      catch(e) {
          accessDenied = true;
      }
      assert.equal(accessDenied, false, "Access not restricted to Contract Owner");
      
  });

  it(`(multiparty) can block access to functions using requireIsOperational when operating status is false`, async function () {

      await config.flightSuretyData.setOperatingStatus(false);

      let reverted = false;
      try 
      {
          await config.flightSurety.setTestingMode(true);
      }
      catch(e) {
          reverted = true;
      }
      assert.equal(reverted, true, "Access not blocked for requireIsOperational");      

      // Set it back for other tests to work
      await config.flightSuretyData.setOperatingStatus(true);

  });

  it('First account is firstAirline', async () => {
    assert.equal(config.firstAirline, accounts[1]);
 
  })


  it('(airline) cannot register an Airline using registerAirline() if it is not funded', async () => {
    
    // ARRANGE
    let callAirline = accounts[1];
    let newAirline = accounts[2];
    

    // ACT
    try {
        await config.flightSuretyApp.registerAirline(newAirline, {from: callAirline});
    }
    catch(e) {

    }
    let result = await config.flightSuretyData.isAirline.call(newAirline); 

    // ASSERT
    assert.equal(result, false, "Airline should not register an airline if it is not funded");

  });

  it('Only existing airline may register a new airline until there are at least four airlines registered', async () => {
    
    // ARRANGE
    let airline1 = accounts[1];
    let airline2 = accounts[2];
    let airline3 = accounts[3];
    let airline4 = accounts[4];

    // ACT
    try {
        await config.flightSuretyApp.registerAirline(airline1, {from: config.owner});
        await config.flightSuretyApp.registerAirline(airline2, {from: config.owner});
        await config.flightSuretyApp.registerAirline(airline3, {from: config.owner});     

        // Try to register 5th airline
        await config.flightSuretyApp.registerAirline(airline4, {from: config.owner});
    }
    catch(e) {
        console.log("register failed");

    }
    let result1 = await config.flightSuretyData.isAirline.call(airline3);
    let result2 = await config.flightSuretyData.isAirline.call(airline4); 

    // ASSERT
    assert.equal(result1, true, "4th airline was not registered");
    assert.equal(result2, false, "5th airline was registered");
    //assert.equal(await config.flightSuretyData.AirlinesCount.call(), 4,"failed number of counts")

  });


  it('(airline) can be registered, but does not participate in contract until it submits funding of 10 ether', async () => {
    
    // ARRANGE
    
    let airline2 = accounts[2];
    let airline3 = accounts[3];
    let funds = web3.utils.toWei("10", "ether");

    try{
        await config.flightSuretyApp.fund({from: airline2, value: funds});
        await config.flightSuretyApp.fund({from: airline3, value: funds});

    }catch(e){
        console.log('Not operetional as a result of failed funding');
    }
    
    let result1 = await config.flightSuretyData.grabAirlineState.call(airline2);
    let result2 = await config.flightSuretyData.grabAirlineState.call(airline3);

    // ASSERT
    assert.equal(result1, true, "Status is not true for airline2"); 
    assert.equal(result2, true, "Status is not true for airline3"); 

  });

  

  it('Registration approval is made when multi-party threshold is reached', async () => {
    
    // ARRANGE

    let airline2 = accounts[2];
    let airline3 = accounts[3];
    let airline4 = accounts[4];
    let registrationStatus = false;
    

   
    try{
        // Registration of the 5th airline will return 3 for potential airlines
         
        let registrationState = await config.flightSuretyApp.registerAirline.call(airline4,  {from: airline3});
        registrationStatus = await config.flightSuretyData.isAirline.call(airline4);
  

        if(registrationState== 3){
        
            await config.flightSuretyApp.approveRegistrations(airline4, true, {from: config.owner});  
            await config.flightSuretyApp.approveRegistrations(airline4, true, {from: airline3});         
            await config.flightSuretyApp.approveRegistrations(airline4, false, {from: airline2});        
        }

        // crossfile the new airline 
        await config.flightSuretyApp.registerAirline(airline4,  {from: airline3});


    }catch(e){
      console.log("not succesful")
        
    }

    let result = await config.flightSuretyData.isAirline.call(airline4);  

    // ASSERT
    assert.equal(result, true, "failed voting from parties");
    assert.equal(registrationStatus, false, "the 5th airline must be registered only through voting");
  
  });
  

  
 
  it('Passengers can purchase flight insurance for at most 1 ether', async () => {
    
    // ARRANGE

    let eth = 1;
    let insurance = web3.utils.toWei(eth.toString(), "ether");
    let passenger = accounts[7];
    let airline = accounts[3];
    console.log(insurance)

    try{
        
        await config.flightSuretyApp.buy(airline,{from: passenger, value: insurance});

    }catch(e){

    }
    
    let result = await config.flightSuretyData.grabInsuredPassenger.call(airline);

    // ASSERT
    assert.equal(result, passenger, "No matching identification")

     

  });


  it('Credit insured passenger on flight delay', async () => {
    
    // ARRANGE
    let passenger = accounts[7];
    let airline = accounts[3];
    let status=true
    let STATUS_CODE_LATE_AIRLINE = 20;
    let flightCode = 'AC1'; 
    let timestamp = Date.now() / 1000 | 0
    let expected_credit = 1.5;

 
    try{
        // prior account credit check
        let priorCredit = await config.flightSuretyApp.passengerInsurance.call({from: passenger});
        priorCredit = web3.utils.fromWei(priorCredit, "ether")
       

        // Credit the passenger via processFlightStatus()
        await config.flightSuretyApp.processFlightStatus(airline, flightCode, timestamp, STATUS_CODE_LATE_AIRLINE);
       

        // Check credit after passenger has been credited via processFlightStatus()
        LaterCredit = await config.flightSuretyApp.passengerInsurance.call({from: passenger});
        LaterCredit = web3.utils.fromWei(LaterCredit, "ether");
    
  

    }catch(e){
      status = false;
    }
    

    // ASSERT
    assert.equal(status, true, "Passenger was not credited");
    assert.equal(LaterCredit, expected_credit,"The right amount was not credited")

  });
 
  it('Credited passenger can withdraw ether', async () => {
    
    // ARRANGE
    let passenger = accounts[7];
    try{   
        priorBalance = await config.flightSuretyApp.passengerInsurance.call({from:passenger})
        //convert to ether
        priorBalance = web3.utils.fromWei(priorBalance, "ether");

        priorEth = await web3.eth.getBalance(passenger)
        priorEth = web3.utils.fromWei(priorEth, "ether");
    
        await config.flightSuretyApp.withdraw({from:passenger});

        LaterBalance = await config.flightSuretyApp.passengerInsurance.call({from:passenger})
        LaterBalance = web3.utils.fromWei(LaterBalance, "ether");

        LaterEth = await web3.eth.getBalance(passenger)
        LaterEth = web3.utils.fromWei(LaterEth, "ether");


    }catch(e){
       
    }
    
    // ASSERT
    assert.ok(priorBalance > 0, "No balance was found");
    assert.ok((LaterEth - priorEth) > 0, "Credited was not transfered to wallet");
    assert.equal(LaterBalance, 0, "Your withdrawal was not succesful"); 

 
  });
  


});
