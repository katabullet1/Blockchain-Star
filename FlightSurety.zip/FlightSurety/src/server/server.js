import FlightSuretyApp from '../../build/contracts/FlightSuretyApp.json';
import FlightSuretyData from '../../build/contracts/FlightSuretyData.json';
import Config from './config.json';
import Web3 from 'web3';
import express from 'express';

let config = Config['localhost'];
let web3 = new Web3(new Web3.providers.WebsocketProvider(config.url.replace('http', 'ws')));
web3.eth.defaultAccount = web3.eth.accounts[0];
let flightSuretyApp = new web3.eth.Contract(FlightSuretyApp.abi, config.appAddress);
let flightSuretyData = new web3.eth.Contract(FlightSuretyData.abi, config.dataAddress);

let GetIndex;

// defines airline status in a dictionary
const STATUSCODES = [{
    "label": "STATUS_CODE_UNKNOWN",
    "status_code": 0
}, 
{
    "label": "STATUS_CODE_ON_TIME",
    "status_code": 10
}, 
{
    "label": "STATUS_CODE_LATE_AIRLINE",
    "status_code": 20
}, 
{
    "label": "STATUS_CODE_LATE_WEATHER",
    "status_code": 30
}, 
{
    "label": "STATUS_CODE_LATE_TECHNICAL",
    "status_code": 40
}, 
{
    "label": "STATUS_CODE_LATE_OTHER",
    "status_code": 50
}];


function grabRandomStatusCode() {
    return STATUSCODES[Math.floor(Math.random() * STATUSCODES.length)];
  }

function initAccounts() {
    return new Promise((resolve, reject) => {
        web3.eth.getAccounts().then(accounts => {
            web3.eth.defaultAccount = accounts[0];
            flightSuretyApp.methods.fund_dapp(accounts[1]).send({
                from: accounts[1],
                value: "10000000000000000000",
                gas: 9999999,
                gasPrice: 20000000000
            }).then(() => {

              
                console.log("Total number of addresses to be registered :"+ accounts.length);
            }).catch(error => {
               
                  console.log("Registration was not successful: " + accounts +  " Error: " + error);
            }).then(() => {
                resolve(accounts);
            });
        }).catch(error => {
            reject(error);
        });
    });
}

function initOracles(accounts) {
    return new Promise((resolve, reject) => {
        let rounds = accounts.length;
        let oracles = [];
        flightSuretyApp.methods.REGISTRATION_FEE().call().then(fee => {
            accounts.forEach(account => {
                flightSuretyApp.methods.registerOracle().send({
                    from: account,
                    value: fee,
                    gas: 9999999,
                    gasPrice: 20000000000
                }).then(() => {
                    flightSuretyApp.methods.getMyIndexes().call({
                        from: account
                    }).then(result => {
                        oracles.push(result);
                       

                        let indices= result[0]+" "+ result[1]+" "+ result[2];
                        console.log("Oracle address [ " +  account + "] " + "has been registered "+ " to indices:" + indices);
                        rounds -= 1;
                        if (!rounds) {
                            resolve(oracles);
                        }
                    }).catch(error => {
                        reject(error);
                    });
                }).catch(error => {
                    reject(error);
                });
            });
        }).catch(error => {
            reject(error);
        });
    });
}

initAccounts().then(accounts => {

    initOracles(accounts).then(oracles => {

        flightSuretyData.events.PurchaseInsurance({
            fromBlock: "latest"
        }, function (error, event) {
            if (error) {
                console.log(error)
            }
            let airline = event.returnValues.airline;
            let flight = event.returnValues.flight;
            let timestamp = event.returnValues.timestamp;
            let oracleResponse = false;  
            let selectedCode = STATUSCODES[Math.floor(Math.random()* STATUSCODES.length)] //STATUSCODES[1];
    
            //loop through oracles and get all items  
            oracles.forEach((oracle, index) => {
                if(!oracleResponse) {
                    for(let i = 0; i < 3; i += 1) {
                        if(oracleResponse) {
                            break;
                        }
                        flightSuretyApp.methods.submitOracleResponse(GetIndex, airline, flight, timestamp, selectedCode.status_code)
                        .send({
                            from: accounts[index]
                        }).then(result => {
                            oracleResponse = true;
                            console.log("The Oracle response was succefuly sent.");
                            console.log(result);
                            //console.log("The Oracle response was succefuly sent. The statuscode is: "  + randomStatusCode + " and index:"+ index +  " for '"+  flight+"'" );
                        }).catch(error => {

                        });
                    }
                }
            });
        });

        flightSuretyApp.events.OracleRequest({
            fromBlock: 0
          }, function (error, event) {
            if (error) console.log(error)
        
            GetIndex = event.returnValues.index;
            console.log(event)
        });

        flightSuretyApp.events.OracleReport({
            fromBlock: 0
          }, function (error, event) {
            if (error) console.log(error)
            console.log(event)
          });


   
 
    
    }).catch(error => {
        console.log(error.message);
    });
}).catch(error => {
    console.log(error.message);
});

const app = express();
 

export default app;