
import DOM from './dom';
import Contract from './contract';
import './flightsurety.css';


(async() => {

    let result = null;

    let contract = new Contract('localhost', () => {

        // Read transaction
        contract.isOperational((error, result) => {
            console.log(error,result);
            display('Operational Status', 'Check if contract is operational', [ { label: 'Operational Status', error: error, value: result} ]);
        });
    



         // User-submitted transaction
         DOM.elid('pay').addEventListener('click', () => {
            let amount = DOM.elid('insurFee').value;
            let flightselect = DOM.elid('ops')
            let flightValue = flightselect.options[flightselect.selectedIndex].value;
            document.getElementById('insurFee').value= "";;
            //DOM.elid('amount').value = "";
                flightValue = JSON.parse(flightValue);
                
                contract.buy(flightValue, amount, (error, result) => {
                    if(error) {
                        alert(error);
                    }
                    display('Flight Insurace', 'Purchased Flight Insurance', [ { label: 'Insurance', error: error, value: ` ${result.amount}  ether of Insurance purchased with Address ${result.airline}      `} ]);
                     
                    //alert("commencing..");
                    });
        });



        DOM.elid('withdrawB').addEventListener('click', () => {
            //let val = 1.5;
            let buyer = DOM.elid('withdraw').value 
            //let res=val*amount

            contract.claims(buyer, (error, result) => {
                if(error) {
                    alert(error);
                }
                //if amount not null
                //alert("all good");
                console.log("Funds withdrawn");
            });
        });
    
  
        // User-submitted transaction
        DOM.elid('submit-oracle').addEventListener('click', () => {
            let flight = DOM.elid('flight-number').value;
            // Write transaction
            
            document.getElementById('flight-number').value = "";
            contract.fetchFlightStatus(flight, (error, result) => {
                let selectFlight = DOM.elid('ops');
                dynamicUpdate(result, selectFlight);

                 
                display('Oracles', 'Trigger oracles', [ { label: 'Fetch Flight Status', error: error, value: result.flight + ' ' + result.timestamp} ]);
            });
        })
    



    });
    

})();






function display(title, description, results) {
    let displayDiv = DOM.elid("display-wrapper");
    let section = DOM.section();
    section.appendChild(DOM.h2(title));
    section.appendChild(DOM.h5(description));
    results.map((result) => {
        let row = section.appendChild(DOM.div({className:'row'}));
        row.appendChild(DOM.div({className: 'col-sm-4 field'}, result.label));
        row.appendChild(DOM.div({className: 'col-sm-8 field-value'}, result.error ? String(result.error) : String(result.value)));
        section.appendChild(row);
    })
    displayDiv.append(section);

}



 function dynamicUpdate(flight, sel) 
 {
              //var option = new Option(text, value);
    var option = new Option(`You are boarding flight  ${flight.flight}  `, JSON.stringify(flight));
            sel.add(option);
    }





